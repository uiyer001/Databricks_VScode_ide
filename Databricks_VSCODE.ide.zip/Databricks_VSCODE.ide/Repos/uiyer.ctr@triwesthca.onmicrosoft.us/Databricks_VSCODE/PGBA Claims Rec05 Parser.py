# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, MapType, TimestampType, FloatType, IntegerType
from pyspark.sql.functions import col, substring
import pandas as pd
import numpy as np
#/*************************************/
#/Specify schema for the header record /
#/*************************************/
claimsDictSchema = StructType([ \
    StructField("Name", StringType(),True), \
    StructField("Pos", IntegerType(),True), \
    StructField("Type1", StringType(),True), \
    StructField("Len", IntegerType(), True), \
    StructField("DD#", StringType(), True), \
    StructField("Sign", StringType(), True), \
    StructField("Pack", StringType(), True), \
    StructField("Occurs", IntegerType(), True), \
    StructField("ColumnName", StringType(), True),\
    StructField("Business Name", StringType(), True)    
  ]);
#/******************************************************/
#Specify connection parameters,
#using storage account and hardcoded key value **********
#/******************************************************/
spark.conf.set(
    "fs.azure.account.key.twdasbxusgadatadl.dfs.core.usgovcloudapi.net",
"+/Au+YDSjr0+JtubIDDkqlXTx29fjC70g3HhhKRpEOsTIsMKuqebYmNS2PRaJgbLgnF/q2rhYWyg+AStXfziSg==")
spark.conf.set("spark.databricks.delta.replaceWhere.constraintCheck.enabled", False)

spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", "true")

spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

#/******************************************************/
#/Read Schema file                                     */ 
#/Schema file created with headers                     */
#/******************************************************/
ClaimsDictDF = spark.read.option("header",True).csv("abfss://tirf@twdasbxusgadatadl.dfs.core.usgovcloudapi.net/dictionaries/pgba-R05-BisName.csv", claimsDictSchema)



#/******************************************************/
#read Data file                                        */
#/******************************************************/
ClaimsDataDF = spark.read.option("inferSchema",True).text("abfss://tirf@twdasbxusgadatadl.dfs.core.usgovcloudapi.net/claims/SETTLED_CLAIMS_PGBA_REG5_05_20230213_obf.TXT")

#/******************************************************/
#use map and collect to create dict dataframe          */
#/******************************************************/

sfDict = map(lambda x: x.asDict(), ClaimsDictDF.collect())
#print(sfDict)

#/******************************************************/
#use .select and substring to parse                    */
#data treated as string                                */
#/******************************************************/

newdf= ClaimsDataDF.select( 
                   [ 
                    (substring(str='value',pos=int(row['Pos']),len=int(row['Len'])) ) .alias(row['ColumnName']) 
                    for row in sfDict
                    ]
)
#/******************************************************/
#write dataframe to the table created befOre           */
#/******************************************************/


newdf.write.format("delta") \
          .mode("append") \
          .option("overwriteSchema", "true") \
            . saveAsTable("claims_raw_record_r05_vscode")
            